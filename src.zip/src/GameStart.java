public class GameStart {
    public static void main(String[] args) {
        new UI();
    }
}
